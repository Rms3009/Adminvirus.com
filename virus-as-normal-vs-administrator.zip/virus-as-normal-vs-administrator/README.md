# Virus as normal vs administrator 

A Pen created on CodePen.

Original URL: [https://codepen.io/Jabir-the-sans/pen/wBBqWKE](https://codepen.io/Jabir-the-sans/pen/wBBqWKE).

